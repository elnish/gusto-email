# Gusto Email Template

PSD to HTML Email exercise.

## Resource

- [Gusto Email PSD Template](http://www.bestpsdfreebies.com/freebie/gusto-email-psd-template/)
